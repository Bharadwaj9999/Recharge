package com.capgemini.hbms.dao;

public interface IQueryMapper {

	String userValidateQuery = "select count(*) from users where user_name=? and password=?";
	String registerUserQuery = "insert into Users values(?,?,?,?,?,?,?,?)";
	String getHotelListQuery = "select * from hotel";
	String getRoomListQuery = "select * from roomdetails where hotel_Id=?";

}
