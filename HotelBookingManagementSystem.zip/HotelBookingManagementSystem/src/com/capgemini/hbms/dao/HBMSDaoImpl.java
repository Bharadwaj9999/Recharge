package com.capgemini.hbms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.capgemini.hbms.bean.HBMSHotelBean;
import com.capgemini.hbms.bean.HBMSRoomBean;
import com.capgemini.hbms.bean.HBMSUserBean;
import com.capgemini.hbms.exception.HBMSException;

public class HBMSDaoImpl implements IHBMSDao{
	InitialContext ic=null;	
	DataSource ds=null;
	Connection con=null;
	
	@Override
	public boolean isValidLoginDetails(String username, String password) throws HBMSException {
		try 
		{
			
			ic=new InitialContext();
			ds=(DataSource) ic.lookup("java:/OracleDS");
			con=ds.getConnection();
			PreparedStatement s=con.prepareStatement(IQueryMapper.userValidateQuery);
			s.setString(1, username);
			s.setString(2, password);
			ResultSet st=s.executeQuery();
			st.next();
			int count=st.getInt(1);
			if(count>0)
			{
				return true;
			}
		}
		catch (NamingException e) 
		{
			throw new HBMSException("error in connection");
		} 
		catch (SQLException e) 
		{
			throw new HBMSException("error in connection");
		}
		
		return false;
	}

	@Override
	public boolean registerUser(HBMSUserBean userBean) throws HBMSException {
		try 
		{
			
			ic=new InitialContext();
			ds=(DataSource) ic.lookup("java:/OracleDS");
			con=ds.getConnection();
			PreparedStatement s=con.prepareStatement(IQueryMapper.registerUserQuery);
			s.setString(1,userBean.getUserId());
			s.setString(2,userBean.getPassword());
			s.setString(3,userBean.getRole());
			s.setString(4, userBean.getUserName());
			s.setString(5, userBean.getMobileNo());
			s.setString(6, userBean.getPhone());
			s.setString(7, userBean.getAddress());
			s.setString(8, userBean.getEmail());
			int result=s.executeUpdate();
			if(result!=0)
			{
				return true;
			}
		}
		catch (NamingException e) 
		{
			throw new HBMSException("error in connection");
		} 
		catch (SQLException e) 
		{
			throw new HBMSException("error in connection");
		}
		return false;
	}

	@Override
	public ArrayList<HBMSHotelBean> getHotelList() throws HBMSException {
		ArrayList<HBMSHotelBean> hotelList=new ArrayList();
		HBMSHotelBean hotel=null;
		try 
		{
			ic=new InitialContext();
			ds=(DataSource) ic.lookup("java:/OracleDS");
			con=ds.getConnection();
			PreparedStatement s=con.prepareStatement(IQueryMapper.getHotelListQuery);
			ResultSet rt=s.executeQuery();
			while(rt.next())
			{
				hotel=new HBMSHotelBean();
				hotel.setHotelId(rt.getString(1));
				hotel.setCity(rt.getString(2));
				hotel.setHotelName(rt.getString(3));
				hotel.setAddress(rt.getString(4));
				hotel.setDescription(rt.getString(5));
				hotel.setAvgRatePerNight(rt.getString(6));
				hotel.setPhoneNo1(rt.getString(7));
				hotel.setPhoneNo2(rt.getString(8));
				hotel.setRating(rt.getString(9));
				hotel.setEmail(rt.getString(10));
				hotel.setFax(rt.getString(11));
				hotelList.add(hotel);
			}
		}
		catch (NamingException e) 
		{
			throw new HBMSException("error in connection");
		} 
		catch (SQLException e) 
		{
			throw new HBMSException("error in connection");
		}
		return hotelList;
	}

	@Override
	public ArrayList<HBMSRoomBean> getRoomList(String id) throws HBMSException {
		ArrayList<HBMSRoomBean> roomList=new ArrayList();
		HBMSRoomBean room=null;
		try 
		{
			ic=new InitialContext();
			ds=(DataSource) ic.lookup("java:/OracleDS");
			con=ds.getConnection();
			PreparedStatement s=con.prepareStatement(IQueryMapper.getRoomListQuery);
			s.setString(1, id);
			ResultSet rt=s.executeQuery();
			while(rt.next())
			{
				room=new HBMSRoomBean();
				room.setHotelId(rt.getString(1));
				room.setRoomId(rt.getString(2));
				room.setRoomNo(rt.getString(3));
				room.setRoomType(rt.getString(4));
				room.setPerNightRate(rt.getFloat(5));
				room.setAvailability(rt.getString(6));
				roomList.add(room);
			}
		}
		catch (NamingException e) 
		{
			throw new HBMSException("error in connection");
		} 
		catch (SQLException e) 
		{
			throw new HBMSException("error in connection");
		}
		return roomList;
	}

}
