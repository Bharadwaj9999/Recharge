package com.capgemini.hbms.service;

import java.util.ArrayList;

import com.capgemini.hbms.bean.HBMSHotelBean;
import com.capgemini.hbms.bean.HBMSRoomBean;
import com.capgemini.hbms.bean.HBMSUserBean;
import com.capgemini.hbms.exception.HBMSException;

public interface IHBMSService {

	boolean isValidLoginDetails(String username, String password) throws HBMSException;

	boolean registerUser(HBMSUserBean userBean) throws HBMSException;

	ArrayList<HBMSHotelBean> getHotelList() throws HBMSException;

	ArrayList<HBMSRoomBean> getRoomList(String id) throws HBMSException;

}
