package com.capgemini.hbms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.capgemini.hbms.bean.HBMSHotelBean;
import com.capgemini.hbms.bean.HBMSRoomBean;
import com.capgemini.hbms.bean.HBMSUserBean;
import com.capgemini.hbms.exception.HBMSException;
import com.capgemini.hbms.service.HBMSServiceImpl;
import com.capgemini.hbms.service.IHBMSService;

/**
 * Servlet implementation class HBMSController
 */
@WebServlet("/HBMSController")
public class HBMSController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HBMSController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String operation=request.getParameter("action");
		PrintWriter write=response.getWriter();
		IHBMSService service=new HBMSServiceImpl();
		try
		{
			if(operation.equals("login"))
			{
				String username=request.getParameter("username");
				String password=request.getParameter("password");
				if(service.isValidLoginDetails(username,password))
				{
					ArrayList<HBMSHotelBean> hotelList=service.getHotelList();
					request.setAttribute("hotellist", hotelList);
					RequestDispatcher rd=request.getRequestDispatcher("/HotelUser.jsp");
					rd.include(request, response);
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
					rd.include(request, response);
					write.print("<font color=red>invalid login details</font>");
				}
			}
			else if(operation.equals("register"))
			{
				HBMSUserBean userBean=new HBMSUserBean();
				userBean.setUserId(request.getParameter("userId"));
				userBean.setPassword(request.getParameter("password"));
				userBean.setUserName(request.getParameter("username"));
				userBean.setMobileNo(request.getParameter("mobilenum"));
				userBean.setPhone(request.getParameter("phonenum"));
				userBean.setAddress(request.getParameter("address"));
				userBean.setEmail(request.getParameter("email"));
				userBean.setRole("user");
				if(service.registerUser(userBean))
				{
					RequestDispatcher rd=request.getRequestDispatcher("/StartPage.jsp");
					rd.include(request, response);
					write.print("<font color=blue>registered sucesfully,login to continue</font>");
				}
				else
				{
					RequestDispatcher rd=request.getRequestDispatcher("/Register.jsp");
					rd.include(request, response);
					write.print("<font color=red>registration unsucessful,please register again</font>");
				}
			}
			else if(operation.equals("roomDetails"))
			{
				String id=request.getParameter("roomid");
				RequestDispatcher rd=request.getRequestDispatcher("/BookingUser.jsp");
				rd.include(request, response);
			}
		}
		catch(HBMSException e)
		{
			write.print(e.getMessage());
		}
	}

}
