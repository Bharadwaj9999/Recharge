package com.org.hbms.dao;

public interface IQueryMapper {
	String userRegisterQuery="insert into Users values(user_id_seq.nextval,?,?,?,?,?,?,?)";
	String userValidQuery="select count(*) from users where user_name=? and password=?";
	String hotelDetailsQuery="select * from hotel";
	String getRoleQuery = "select * from Users where user_name=? and password=?";
	String displayRoomQuery = "select * from roomdetails where hotel_Id=?";
	String validHotelQuery = "select count(*) from hotel where hotel_id=?";
	String hotelAddQuery = "insert into hotel values(hotel_id_seq.nextval,?,?,?,?,?,?,?,?,?,?)";
	String deleteHotelQuery = "delete from hotel where hotel_id=?";
	String deleteHotelRoomQuery = "delete from RoomDetails where hotel_id=?";
	String addRoomDetailsQuery = "insert into roomDetails values(?,room_id_seq.nextval,?,?,?,?)";
	String validRoomQuery = "select count(*) from roomDetails where room_id=?";
	String deleteRoomQuery = "delete from RoomDetails where room_id=?";
	String getRoomAmountQuery = "select per_night_rate from roomdetails where room_id=?";
	String addBookingDetailsQuery ="insert into bookingdetails values(booking_id_seq.nextval,?,?,?,?,?,?,?)";
	String bookingIdQuery="select booking_id_seq.nextval from dual";
	String getUserIdQuery = "select user_id_seq.currval from dual";
	String getBookingId = "select booking_id_seq.currval from dual";
	String getHotelId = "select hotel_id_seq.currval from dual";
	String getRoomIdQuery = "select room_id_seq.currval from dual";
	String getBookingOfHotelQuery = "select * from bookingdetails b,roomdetails r where r.room_id=b.room_id and r.hotel_id=?";
	String getGuestListQuery = "select u.user_name,u.mobile_no,u.email from users u,roomdetails r,bookingdetails b where r.room_id=b.room_id and u.user_id=b.user_id and r.hotel_id=?";
	String changeStatusQuery = "update table roomdetails set availability='false' where room_id=?";
	String getBookingListQuery = "select * from bookingdetails where booked_from=?";
	String checkAvailabilityQuery = "update roomdetails set availability='true' where room_id IN (select room_id from bookingdetails where booked_to>sysdate)";
}